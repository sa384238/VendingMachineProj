//As we have no external database so taken inmemory json array to store list of purchased products
var products = [
    {
        name: "Coke",
        price: 2,
        quantity: 3
    },
    {
        name: "Pepsi",
        price: 3,
        quantity: 4
    },
    {
        name: "Red Bull",
        price: 1,
        quantity: 9
    },
    {
        name: "Mountain Dew",
        price: 1,
        quantity: 4
    },
    {
        name: "Fizz",
        price: 1,
        quantity: 5
    },
    {
        name: "Fanta",
        price: 2,
        quantity: 6
    }
];

const purchasedProductList = [];

function getProductDetails(productName) {
    var product = null;
    products.forEach(function (prod) {
        if (prod.name === productName) {
            product = prod;
        }
    });
    return product;
}

function checkAndDispenseProduct(event) {
    var selectedProductId = event.target.id;
    var selectedProduct = getProductDetails(selectedProductId);
    var coinAmount = document.getElementById("Coin").value;
    if (coinAmount >= selectedProduct.price) {
        dispensePrdouct(selectedProduct);
    } else {
        showErrorMessage(selectedProduct);
    }
}

function dispensePrdouct(product) {
    var coinAmount = document.getElementById("Coin").value;
    if (coinAmount >= product.price) {
        coinAmount = coinAmount - product.price
        document.getElementById("success").innerHTML = product.name + " dispensed successfully ";
        document.getElementById("amountleft").innerHTML = "Please collect remaining amount : " + coinAmount;
        product.quantity = product.quantity - 1;
        purchasedProductList.push(product.name + ', ');
        document.getElementById("items").innerHTML = "Purchase History :" + purchasedProductList.join("");
        document.getElementById("Coin").value = '';
        document.getElementById("success").style.display = "block";
        document.getElementById("amountleft").style.display = "block";
        document.getElementById("items").style.display = "block";
        document.getElementById("Error").style.display = "none";
    }
}

function showErrorMessage(product) {
    document.getElementById("Error").innerHTML = "Insufficient amount, Please insert more than $" + product.price + " and click on " + product.name + " to purchase";
    if (document.getElementById("Error").style.display === "none") {
        document.getElementById("Error").style.display = "block";
        document.getElementById("success").style.display = "none";
        document.getElementById("amountleft").style.display = "none";
        document.getElementById("items").style.display = "none";
    }
}